-- pt-br.lua
return {
    ["Start"] = "Iniciar",
    ["End"] = "Final",
}
