-- Request.lua
local Request = {}

function Request:Post(url)
    print("Enviando requisição para: " .. url)
end

return Request
